<?php
    define('DB_HOST', 'bcitdevcom.ipagemysql.com');
    define('DB_USER', 'comp15362014');
    define('DB_PASSWORD', '2014-1536');
    define('DB_DATABASE', '1536forum');
    define('HOMEURL', 'index.php');
?>